HPP PRO - PROYEK ANDROID

Cara membuat APK:
1. Ekstrak ZIP ini.
2. Buat akun/login GitHub.
3. Buat repository baru bernama HPP-Pro.
4. Upload semua isi folder proyek ini ke repository (termasuk folder .github).
5. Buka tab Actions di repository, pilih workflow "Build HPP PRO APK".
6. Tekan Run workflow dan tunggu sampai selesai.
7. Buka hasil workflow yang berhasil, unduh artifact bernama HPP-PRO-APK.
8. Ekstrak artifact ZIP, lalu ambil app-debug.apk.
9. Kirim APK ke HP Android, buka file tersebut, izinkan pemasangan dari sumber ini jika diminta, lalu Install.

Catatan:
- Ini APK debug untuk penggunaan pribadi/pengujian, belum ditandatangani untuk distribusi Play Store.
- Data produk disimpan lokal di perangkat melalui penyimpanan browser WebView.
- Untuk menjaga data, jangan hapus data aplikasi atau uninstall tanpa membuat cadangan.
- Android SDK/Gradle tidak disertakan; GitHub Actions mengunduh dan menyiapkannya saat build.
